Poker v12: Kartenmodelle fuer Minecraft Java 1.20.6 und 1.21.8. Alte CMD-Overrides und neue 1.21.4+ Item-Definitionen enthalten. Andere Versionen nicht getestet.
