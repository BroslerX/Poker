Poker v11: GUI-Hilfe und Lobbyzeit werden serverseitig in der JAR angezeigt. Kartentexturen unveraendert.
