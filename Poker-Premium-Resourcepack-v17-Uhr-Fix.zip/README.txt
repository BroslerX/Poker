Poker v16 resource pack. Supports legacy item model overrides and modern item definitions. Client versions 1.20.6 and 1.21.8 should be tested individually.
